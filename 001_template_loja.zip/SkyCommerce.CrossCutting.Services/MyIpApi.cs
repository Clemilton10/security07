﻿namespace SkyCommerce.CrossCutting.Services
{
    public class MyIpApi
    {
        public string ip { get; set; }
        public string country { get; set; }
        public string cc { get; set; }
    }
}